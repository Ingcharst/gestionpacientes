"""
Módulo API para procedimientos.
"""
