"""
URL configuration for tea_management project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularSwaggerView,
    SpectacularRedocView,
)

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # API Documentation
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    
    # JWT Authentication
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
    # API Endpoints
    path('api/usuarios/', include('apps.usuarios.api.urls')),
    path('api/consultorios/', include('apps.consultorios.api.urls')),
    path('api/terapias/', include('apps.terapias.api.urls')),
    path('api/procedimientos/', include('apps.procedimientos.api.urls')),
    
    # Frontend Views
    path('', include('apps.usuarios.urls')),
    path('consultorios/', include('apps.consultorios.urls')),
    path('terapias/', include('apps.terapias.urls')),
    path('procedimientos/', include('apps.procedimientos.urls')),
    path('grupos/', include('apps.grupos.urls')),
    path('reportes/', include('apps.reportes.urls')),
    path('alertas/', include('apps.alertas.urls')),
]

# Configuración de Admin
admin.site.site_header = 'TEA Management System'
admin.site.site_title = 'Administración TEA'
admin.site.index_title = 'Panel de Administración'

# Servir archivos media en desarrollo
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

