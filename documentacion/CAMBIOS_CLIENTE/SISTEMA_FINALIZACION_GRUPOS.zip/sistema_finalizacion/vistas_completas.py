# ✅ VISTAS: Historial y Reasignación de Grupos
# Archivo: apps/grupos/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import transaction
from datetime import date

from .models import GrupoTerapeutico, AsignacionGrupo
from apps.procedimientos.models import Paciente, AdmisionTerapia


# ============================================================================
# VISTA: Historial de Grupos del Paciente
# ============================================================================

@login_required
def historial_grupos_paciente(request, paciente_id):
    """
    Muestra historial completo de asignaciones a grupos del paciente.
    Incluye: activas, finalizadas, suspendidas, canceladas.
    """
    paciente = get_object_or_404(Paciente, pk=paciente_id)
    
    # Obtener todas las asignaciones del paciente
    asignaciones = AsignacionGrupo.objects.filter(
        paciente=paciente
    ).select_related(
        'grupo',
        'grupo__terapia',
        'admision_terapia'
    ).prefetch_related(
        'grupo__terapeuta_responsable'
    ).order_by('-fecha_inicio_asignacion')
    
    # Separar por estado para mejor visualización
    activas = asignaciones.filter(estado='ACTIVA')
    finalizadas = asignaciones.filter(estado='FINALIZADA')
    suspendidas = asignaciones.filter(estado='SUSPENDIDA')
    canceladas = asignaciones.filter(estado='CANCELADA')
    
    # Buscar admisiones vigentes sin asignación activa
    admisiones_sin_grupo = AdmisionTerapia.objects.filter(
        paciente=paciente,
        estado='VIGENTE',
        fecha_inicio__lte=date.today(),
        fecha_fin__gte=date.today()
    ).exclude(
        # Excluir las que ya tienen asignación activa
        id__in=activas.values_list('admision_terapia_id', flat=True)
    ).select_related('terapia')
    
    # Estadísticas generales
    total_grupos_historico = asignaciones.values('grupo').distinct().count()
    total_asignaciones = asignaciones.count()
    
    context = {
        'paciente': paciente,
        'activas': activas,
        'finalizadas': finalizadas,
        'suspendidas': suspendidas,
        'canceladas': canceladas,
        'admisiones_sin_grupo': admisiones_sin_grupo,
        'total_grupos_historico': total_grupos_historico,
        'total_asignaciones': total_asignaciones,
        'titulo': f'Historial de Grupos - {paciente.nombre_completo}'
    }
    
    return render(request, 'grupos/historial_grupos_paciente.html', context)


# ============================================================================
# VISTA: Reasignar a Grupo Anterior
# ============================================================================

@login_required
def reasignar_a_grupo_anterior(request, asignacion_id):
    """
    Reasigna al paciente al mismo grupo de una asignación finalizada/suspendida.
    Mantiene grupo, días y horarios.
    Requiere nueva admisión vigente.
    """
    asignacion_anterior = get_object_or_404(
        AsignacionGrupo.objects.select_related(
            'paciente',
            'grupo',
            'grupo__terapia',
            'admision_terapia'
        ),
        pk=asignacion_id
    )
    
    paciente = asignacion_anterior.paciente
    grupo = asignacion_anterior.grupo
    
    # Verificar que pueda reactivarse
    if not asignacion_anterior.puede_reactivar():
        messages.error(
            request,
            f'La asignación está en estado {asignacion_anterior.get_estado_display()} '
            'y no puede reactivarse'
        )
        return redirect('grupos:historial_grupos_paciente', paciente_id=paciente.id)
    
    # POST: Procesar reasignación
    if request.method == 'POST':
        admision_id = request.POST.get('admision_id')
        
        if not admision_id:
            messages.error(request, 'Debe seleccionar una admisión')
            return redirect(request.path)
        
        nueva_admision = get_object_or_404(AdmisionTerapia, pk=admision_id)
        
        # Validar que sea del paciente
        if nueva_admision.paciente != paciente:
            messages.error(request, 'La admisión no pertenece al paciente')
            return redirect('grupos:historial_grupos_paciente', paciente_id=paciente.id)
        
        # Intentar reactivar
        try:
            with transaction.atomic():
                nueva_asignacion, mensaje = asignacion_anterior.reactivar_asignacion(
                    nueva_admision=nueva_admision,
                    usuario=request.user
                )
                
                if nueva_asignacion:
                    # Actualizar estado del paciente si es necesario
                    if paciente.estado != 'ACTIVO':
                        paciente.estado = Paciente.Estado.ACTIVO
                        paciente.save(update_fields=['estado'])
                    
                    messages.success(
                        request,
                        f'✅ {paciente.nombre_completo} reasignado exitosamente a {grupo.nombre}. '
                        f'Mantiene horario: {", ".join(asignacion_anterior.dias_asistencia)}'
                    )
                    return redirect('grupos:grupo_detail', pk=grupo.id)
                else:
                    messages.error(request, f'❌ {mensaje}')
                    return redirect(request.path)
                    
        except Exception as e:
            messages.error(request, f'Error al reasignar: {str(e)}')
            return redirect('grupos:historial_grupos_paciente', paciente_id=paciente.id)
    
    # GET: Mostrar formulario de confirmación
    
    # Buscar admisiones vigentes para la misma terapia
    admisiones_disponibles = AdmisionTerapia.objects.filter(
        paciente=paciente,
        terapia=grupo.terapia,
        estado='VIGENTE',
        fecha_inicio__lte=date.today(),
        fecha_fin__gte=date.today()
    ).exclude(
        # Excluir las que ya tienen asignación activa
        asignaciones_grupo__estado='ACTIVA'
    ).select_related('terapia')
    
    if not admisiones_disponibles.exists():
        messages.error(
            request,
            f'El paciente no tiene admisiones vigentes disponibles para {grupo.terapia.nombre}'
        )
        return redirect('grupos:historial_grupos_paciente', paciente_id=paciente.id)
    
    # Verificar cupo actual del grupo
    cupo_actual = AsignacionGrupo.objects.filter(
        grupo=grupo,
        estado='ACTIVA'
    ).count()
    
    cupo_disponible = grupo.capacidad_maxima - cupo_actual
    
    context = {
        'asignacion_anterior': asignacion_anterior,
        'paciente': paciente,
        'grupo': grupo,
        'admisiones_disponibles': admisiones_disponibles,
        'cupo_actual': cupo_actual,
        'cupo_disponible': cupo_disponible,
        'titulo': f'Reasignar a {grupo.nombre}'
    }
    
    return render(request, 'grupos/reasignar_grupo.html', context)


# ============================================================================
# VISTA: Finalizar Asignación Manualmente
# ============================================================================

@login_required
def finalizar_asignacion_manual(request, asignacion_id):
    """
    Finaliza manualmente una asignación activa.
    Útil cuando el paciente no puede continuar por motivos externos.
    """
    asignacion = get_object_or_404(
        AsignacionGrupo.objects.select_related('paciente', 'grupo'),
        pk=asignacion_id
    )
    
    if not asignacion.puede_finalizar_manualmente:
        messages.error(
            request,
            f'La asignación está en estado {asignacion.get_estado_display()} '
            'y no puede finalizarse'
        )
        return redirect('grupos:grupo_detail', pk=asignacion.grupo.id)
    
    if request.method == 'POST':
        motivo = request.POST.get('motivo', 'Finalización manual')
        
        try:
            asignacion.finalizar_asignacion(
                motivo=motivo,
                automatico=False,
                usuario=request.user
            )
            
            messages.success(
                request,
                f'✅ Asignación de {asignacion.paciente.nombre_completo} finalizada. '
                'El cupo ha sido liberado.'
            )
            
        except Exception as e:
            messages.error(request, f'Error al finalizar: {str(e)}')
        
        return redirect('grupos:grupo_detail', pk=asignacion.grupo.id)
    
    # GET: Mostrar confirmación
    context = {
        'asignacion': asignacion,
        'titulo': 'Finalizar Asignación'
    }
    
    return render(request, 'grupos/finalizar_asignacion.html', context)


# ============================================================================
# MODIFICAR: control_asistencia_grupo (agregar verificación finalización)
# ============================================================================

# En la función existente control_asistencia_grupo, agregar después de incrementar cantidad_realizada:

"""
# Dentro del bucle donde se procesan asistencias:

if asistio and asig.admision_terapia:
    admision = asig.admision_terapia
    admision.cantidad_realizada += 1
    admision.save()
    
    # ✅ AGREGAR ESTA VERIFICACIÓN:
    if asig.verificar_finalizacion():
        messages.info(
            request,
            f'✅ {asig.paciente.nombre_completo} completó sus {admision.cantidad_ordenada} terapias. '
            f'El cupo ha sido liberado automáticamente.'
        )
"""
