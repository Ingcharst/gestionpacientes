# ✅ CÓDIGO: Métodos para AsignacionGrupo
# Archivo: apps/grupos/models.py
# Agregar estos métodos a la clase AsignacionGrupo

def verificar_finalizacion(self):
    """
    Verifica si la asignación debe finalizarse automáticamente.
    Se llama después de registrar cada asistencia.
    
    Returns:
        bool: True si se finalizó, False si no
    """
    if self.estado != 'ACTIVA':
        return False
    
    if not self.admision_terapia:
        return False
    
    # Verificar si completó el número de terapias ordenadas
    if self.admision_terapia.cantidad_realizada >= self.admision_terapia.cantidad_ordenada:
        self.finalizar_asignacion(
            motivo='Completó el número de terapias ordenadas',
            automatico=True
        )
        return True
    
    return False


def finalizar_asignacion(self, motivo='', automatico=False, usuario=None):
    """
    Finaliza la asignación al grupo.
    - Cambia estado a FINALIZADA
    - Libera el cupo
    - Mantiene el historial
    
    Args:
        motivo: Razón de la finalización
        automatico: Si es automático o manual
        usuario: Usuario que finalizó (si es manual)
    
    Returns:
        bool: True si se finalizó correctamente
    """
    from django.utils import timezone
    
    self.estado = 'FINALIZADA'
    self.fecha_fin_asignacion = timezone.now().date()
    self.motivo_suspension = motivo or 'Terapias completadas'
    
    # Agregar metadata de finalización a notas
    if not self.notas:
        self.notas = ''
    
    self.notas += f'\n\n[FINALIZACIÓN - {timezone.now().strftime("%Y-%m-%d %H:%M")}]\n'
    self.notas += f'Razón: {motivo}\n'
    
    if self.admision_terapia:
        self.notas += f'Terapias realizadas: {self.admision_terapia.cantidad_realizada}/{self.admision_terapia.cantidad_ordenada}\n'
    
    if usuario:
        self.notas += f'Finalizado por: {usuario.get_full_name()}\n'
    elif automatico:
        self.notas += 'Finalización automática del sistema\n'
    
    self.save(update_fields=['estado', 'fecha_fin_asignacion', 'motivo_suspension', 'notas'])
    
    return True


def puede_reactivar(self):
    """
    Verifica si la asignación puede reactivarse.
    
    Returns:
        bool: True si puede reactivarse
    """
    return self.estado in ['FINALIZADA', 'SUSPENDIDA']


def reactivar_asignacion(self, nueva_admision, usuario=None):
    """
    Reactiva la asignación con una nueva admisión.
    Crea una NUEVA asignación manteniendo grupo, días y horarios.
    La asignación anterior se mantiene como historial.
    
    Args:
        nueva_admision: AdmisionTerapia nueva para vincular
        usuario: Usuario que reactiva (opcional)
    
    Returns:
        tuple: (AsignacionGrupo|None, mensaje)
    """
    from django.utils import timezone
    
    # Validación 1: Puede reactivarse
    if not self.puede_reactivar():
        return None, f'La asignación está en estado {self.get_estado_display()} y no puede reactivarse'
    
    # Validación 2: Misma terapia
    if nueva_admision.terapia != self.grupo.terapia:
        return None, f'La admisión debe ser para {self.grupo.terapia.nombre}'
    
    # Validación 3: Verificar cupo disponible
    asignaciones_activas = AsignacionGrupo.objects.filter(
        grupo=self.grupo,
        estado='ACTIVA'
    ).count()
    
    if asignaciones_activas >= self.grupo.capacidad_maxima:
        return None, f'El grupo está lleno ({asignaciones_activas}/{self.grupo.capacidad_maxima})'
    
    # Validación 4: No duplicar asignación activa
    if AsignacionGrupo.objects.filter(
        paciente=self.paciente,
        grupo=self.grupo,
        estado='ACTIVA'
    ).exists():
        return None, 'El paciente ya tiene una asignación activa en este grupo'
    
    # ✅ Crear NUEVA asignación (mantiene historial de la anterior)
    nueva_asignacion = AsignacionGrupo.objects.create(
        paciente=self.paciente,
        grupo=self.grupo,
        admision_terapia=nueva_admision,
        dias_asistencia=self.dias_asistencia,  # ✅ Mantiene mismos días
        numero_terapias_semanales=self.numero_terapias_semanales,  # ✅ Mismo horario
        numero_terapias_asignadas=nueva_admision.cantidad_ordenada,
        estado='ACTIVA',
        fecha_inicio_asignacion=timezone.now().date(),
        notas=f'[REASIGNACIÓN]\n'
              f'Basada en asignación anterior (ID: {self.id})\n'
              f'Grupo: {self.grupo.nombre}\n'
              f'Días previos: {", ".join(self.dias_asistencia)}\n'
              f'Nueva admisión: {nueva_admision.numero_admision}\n'
              f'Fecha reasignación: {timezone.now().strftime("%Y-%m-%d %H:%M")}\n'
    )
    
    # Agregar nota a la asignación ANTERIOR
    if not self.notas:
        self.notas = ''
    
    self.notas += f'\n\n[REASIGNACIÓN - {timezone.now().strftime("%Y-%m-%d %H:%M")}]\n'
    self.notas += f'Nueva asignación creada: ID {nueva_asignacion.id}\n'
    self.notas += f'Nueva admisión: {nueva_admision.numero_admision}\n'
    
    if usuario:
        self.notas += f'Reasignado por: {usuario.get_full_name()}\n'
    
    self.save(update_fields=['notas'])
    
    return nueva_asignacion, 'Reasignación exitosa'


@property
def puede_finalizar_manualmente(self):
    """Indica si puede finalizarse manualmente"""
    return self.estado == 'ACTIVA'


# ============================================================================
# TAMBIÉN AGREGAR/MODIFICAR EN Meta:
# ============================================================================

class Meta:
    db_table = 'grupos_asignacion_grupo'
    verbose_name = 'Asignación a Grupo'
    verbose_name_plural = 'Asignaciones a Grupos'
    ordering = ['-fecha_inicio_asignacion']
    
    # ✅ AGREGAR ESTOS ÍNDICES:
    indexes = [
        models.Index(fields=['estado', 'grupo']),  # Para contar cupos
        models.Index(fields=['paciente', 'estado']),  # Para historial
        models.Index(fields=['grupo', 'fecha_inicio_asignacion']),
        models.Index(fields=['admision_terapia', 'estado']),
    ]


# ============================================================================
# MIGRACIÓN NECESARIA
# ============================================================================

# Después de agregar estos métodos, ejecutar:
# python manage.py makemigrations grupos
# python manage.py migrate
