#!/usr/bin/env python
"""
Script para actualizar estados de pacientes pendientes de asignación.
Ejecutar: python manage.py shell < actualizar_estados_pendientes.py
"""

from apps.procedimientos.models import Paciente

print("=" * 70)
print("SCRIPT: Actualizar estados de pacientes pendientes de asignación")
print("=" * 70)

# ============================================================================
# 1. ACTUALIZAR PACIENTES CON VALORACIÓN COMPLETADA
# ============================================================================

print("\n1. Buscando pacientes con valoración completada...")

pacientes_con_valoracion = Paciente.objects.filter(
    valoracion_inicial__completada=True
).exclude(
    estado='PENDIENTE_ASIGNACION'
)

count = pacientes_con_valoracion.count()
print(f"   Encontrados: {count} pacientes")

if count > 0:
    print("\n   Pacientes a actualizar:")
    for p in pacientes_con_valoracion:
        print(f"     - {p.nombre_completo} (Estado actual: {p.get_estado_display()})")
    
    # Actualizar estado
    pacientes_con_valoracion.update(estado='PENDIENTE_ASIGNACION')
    print(f"\n   ✅ {count} pacientes actualizados a PENDIENTE_ASIGNACION")
else:
    print("   ℹ️  No hay pacientes con valoración completada en otros estados")

# ============================================================================
# 2. DIAGNÓSTICO DETALLADO
# ============================================================================

print("\n" + "=" * 70)
print("2. DIAGNÓSTICO DEL SISTEMA")
print("=" * 70)

# Valoraciones sin completar
sin_completar = Paciente.objects.filter(
    valoracion_inicial__completada=False
).count()
print(f"\n📝 Valoraciones SIN completar: {sin_completar}")

if sin_completar > 0:
    print("   Pacientes:")
    for p in Paciente.objects.filter(valoracion_inicial__completada=False)[:5]:
        print(f"     - {p.nombre_completo}")
    if sin_completar > 5:
        print(f"     ... y {sin_completar - 5} más")

# Pacientes sin valoración
sin_valoracion = Paciente.objects.filter(
    valoracion_inicial__isnull=True
).count()
print(f"\n❌ Pacientes SIN valoración: {sin_valoracion}")

if sin_valoracion > 0:
    print("   Pacientes:")
    for p in Paciente.objects.filter(valoracion_inicial__isnull=True)[:5]:
        print(f"     - {p.nombre_completo} (Estado: {p.get_estado_display()})")
    if sin_valoracion > 5:
        print(f"     ... y {sin_valoracion - 5} más")

# Estados actuales
print("\n📊 Distribución por estado:")
for estado_code, estado_name in Paciente.Estado.choices:
    c = Paciente.objects.filter(estado=estado_code).count()
    if c > 0:
        print(f"   {estado_name}: {c}")

# ============================================================================
# 3. VERIFICAR PENDIENTES DE ASIGNACIÓN
# ============================================================================

print("\n" + "=" * 70)
print("3. VERIFICACIÓN FINAL")
print("=" * 70)

pendientes = Paciente.objects.filter(
    estado='PENDIENTE_ASIGNACION'
)

print(f"\n✅ Total pacientes PENDIENTE_ASIGNACION: {pendientes.count()}")

if pendientes.exists():
    print("\n   Pacientes pendientes:")
    for p in pendientes:
        tiene_val = "✓" if hasattr(p, 'valoracion_inicial') else "✗"
        val_completa = "✓" if hasattr(p, 'valoracion_inicial') and p.valoracion_inicial.completada else "✗"
        print(f"     - {p.nombre_completo}")
        print(f"       Valoración: {tiene_val} | Completada: {val_completa}")

# ============================================================================
# 4. VERIFICAR ASIGNACIONES A GRUPOS
# ============================================================================

from apps.grupos.models import AsignacionGrupo

print("\n" + "=" * 70)
print("4. VERIFICAR ASIGNACIONES A GRUPOS")
print("=" * 70)

# Pacientes con asignación activa
con_grupo = Paciente.objects.filter(
    id__in=AsignacionGrupo.objects.filter(
        estado='ACTIVA'
    ).values_list('paciente_id', flat=True)
).count()

print(f"\n👥 Pacientes con grupo activo: {con_grupo}")

# Pacientes pendientes SIN grupo
pendientes_sin_grupo = Paciente.objects.filter(
    estado='PENDIENTE_ASIGNACION'
).exclude(
    id__in=AsignacionGrupo.objects.filter(
        estado='ACTIVA'
    ).values_list('paciente_id', flat=True)
).count()

print(f"⚠️  Pendientes SIN grupo: {pendientes_sin_grupo}")

# ============================================================================
# 5. RECOMENDACIONES
# ============================================================================

print("\n" + "=" * 70)
print("5. RECOMENDACIONES")
print("=" * 70)

if sin_completar > 0:
    print("\n⚠️  Acción requerida:")
    print(f"   Hay {sin_completar} valoraciones incompletas.")
    print("   Completar las valoraciones para que aparezcan en pendientes.")

if sin_valoracion > 0:
    print("\n⚠️  Acción requerida:")
    print(f"   Hay {sin_valoracion} pacientes sin valoración.")
    print("   Crear valoración inicial para estos pacientes.")

if pendientes_sin_grupo > 0:
    print("\n✅ Listo para asignar:")
    print(f"   Hay {pendientes_sin_grupo} pacientes listos para asignar a grupos.")
    print("   Visitar: /procedimientos/pacientes/pendientes-asignacion/")
else:
    print("\nℹ️  No hay pacientes pendientes de asignación en este momento.")

print("\n" + "=" * 70)
print("SCRIPT COMPLETADO")
print("=" * 70)
