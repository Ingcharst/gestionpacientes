# ✅ MÉTODO SAVE() CORREGIDO - ValoracionInicial
# Archivo: apps/procedimientos/models.py
# Clase: ValoracionInicial
# Ubicación: Línea ~1962

def save(self, *args, **kwargs):
    """
    Override save para:
    1. Generar código de valoración único
    2. Actualizar estado del paciente cuando se completa la valoración
    
    ✅ CORRECCIÓN: Detecta cambio de estado de completada para evitar duplicados
    """
    from django.utils import timezone
    import random
    
    # =========================================================================
    # 1. GENERAR CÓDIGO DE VALORACIÓN (Si no existe)
    # =========================================================================
    if not self.codigo_valoracion:
        fecha_str = timezone.now().strftime('%Y%m%d')
        random_suffix = str(random.randint(1000, 9999))
        self.codigo_valoracion = f"VAL-{fecha_str}-{random_suffix}"
        
        # Verificar unicidad del código
        while ValoracionInicial.objects.filter(
            codigo_valoracion=self.codigo_valoracion
        ).exists():
            random_suffix = str(random.randint(1000, 9999))
            self.codigo_valoracion = f"VAL-{fecha_str}-{random_suffix}"
    
    # =========================================================================
    # 2. DETECTAR CAMBIO EN CAMPO 'completada'
    # =========================================================================
    cambio_completada = False
    
    if self.pk:  # Si la valoración ya existe en BD
        try:
            # Obtener estado anterior
            valoracion_anterior = ValoracionInicial.objects.get(pk=self.pk)
            
            # ✅ Detectar cambio de False → True
            if not valoracion_anterior.completada and self.completada:
                cambio_completada = True
                
        except ValoracionInicial.DoesNotExist:
            # No debería ocurrir, pero por seguridad
            if self.completada:
                cambio_completada = True
    else:
        # Es una nueva valoración
        if self.completada:
            cambio_completada = True
    
    # =========================================================================
    # 3. CAMBIAR ESTADO DEL PACIENTE (Solo si cambió a completada)
    # =========================================================================
    if cambio_completada:
        # Establecer fecha de completación
        if not self.fecha_completada:
            self.fecha_completada = timezone.now()
        
        # ✅ Cambiar estado del paciente a PENDIENTE_ASIGNACION
        # Solo si no está ya asignado a grupo
        from apps.grupos.models import AsignacionGrupo
        
        tiene_grupo_activo = AsignacionGrupo.objects.filter(
            paciente=self.paciente,
            estado='ACTIVA'
        ).exists()
        
        if not tiene_grupo_activo:
            # Cambiar a PENDIENTE_ASIGNACION
            self.paciente.estado = Paciente.Estado.PENDIENTE_ASIGNACION
            self.paciente.save(update_fields=['estado'])
        else:
            # Ya tiene grupo, cambiar a ACTIVO
            self.paciente.estado = Paciente.Estado.ACTIVO
            self.paciente.save(update_fields=['estado'])
    
    # =========================================================================
    # 4. GUARDAR LA VALORACIÓN
    # =========================================================================
    super().save(*args, **kwargs)


# ============================================================================
# EXPLICACIÓN DE LA CORRECCIÓN
# ============================================================================

"""
ANTES (con bug):
- Condición: if self.completada and not self.fecha_completada
- Problema: Solo ejecuta la primera vez
- Resultado: Si se edita después, no vuelve a cambiar estado

DESPUÉS (corregido):
- Detecta cambio de False → True en campo completada
- Ejecuta solo cuando realmente se marca como completada
- Evita ejecuciones múltiples innecesarias
- Verifica si tiene grupo activo antes de cambiar estado

VENTAJAS:
✅ Detecta cambio real de estado
✅ No ejecuta múltiples veces
✅ Verifica grupo activo antes de cambiar
✅ Más robusto y predecible
"""


# ============================================================================
# IMPLEMENTACIÓN
# ============================================================================

"""
PASOS:

1. Abrir: apps/procedimientos/models.py

2. Buscar clase ValoracionInicial (línea ~1681)

3. Buscar método save() (línea ~1962)

4. REEMPLAZAR el método completo con el código de arriba

5. Guardar archivo

6. NO requiere migración (solo cambio de lógica)

7. Reiniciar servidor:
   python manage.py runserver

8. Probar:
   - Completar una valoración
   - Verificar que estado cambia a PENDIENTE_ASIGNACION
   - Verificar que aparece en lista de pendientes
"""


# ============================================================================
# ALTERNATIVA: Método más simple (sin verificar grupo)
# ============================================================================

def save_alternativo(self, *args, **kwargs):
    """Versión simplificada sin verificar grupo activo"""
    from django.utils import timezone
    import random
    
    # Generar código
    if not self.codigo_valoracion:
        fecha_str = timezone.now().strftime('%Y%m%d')
        random_suffix = str(random.randint(1000, 9999))
        self.codigo_valoracion = f"VAL-{fecha_str}-{random_suffix}"
        
        while ValoracionInicial.objects.filter(
            codigo_valoracion=self.codigo_valoracion
        ).exists():
            random_suffix = str(random.randint(1000, 9999))
            self.codigo_valoracion = f"VAL-{fecha_str}-{random_suffix}"
    
    # Detectar cambio a completada
    cambio_completada = False
    if self.pk:
        try:
            anterior = ValoracionInicial.objects.get(pk=self.pk)
            cambio_completada = not anterior.completada and self.completada
        except ValoracionInicial.DoesNotExist:
            cambio_completada = self.completada
    else:
        cambio_completada = self.completada
    
    # Cambiar estado si se completó
    if cambio_completada:
        self.fecha_completada = timezone.now()
        self.paciente.estado = Paciente.Estado.PENDIENTE_ASIGNACION
        self.paciente.save(update_fields=['estado'])
    
    super().save(*args, **kwargs)

"""
Esta versión alternativa es más simple pero no verifica si ya tiene grupo.
Úsala si prefieres simplicidad sobre lógica compleja.
"""
